package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private var torchOn = false
    private val requestSpeech = 100
    private val requestAudioPermission = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 60, 36, 36)
            setBackgroundColor(android.graphics.Color.rgb(6, 17, 31))
        }
        status = TextView(this).apply {
            text = "JARVIS ONLINE\nTap the microphone button and speak."
            textSize = 22f
            setTextColor(android.graphics.Color.WHITE)
            setPadding(0, 20, 0, 40)
        }
        val listen = Button(this).apply {
            text = "🎙  TALK TO JARVIS"
            setOnClickListener { startListening() }
        }
        val torch = Button(this).apply {
            text = "Flashlight ON / OFF"
            setOnClickListener { toggleTorch() }
        }
        val help = Button(this).apply {
            text = "Example commands"
            setOnClickListener {
                say("Try: open YouTube, open WhatsApp, flashlight on, volume up, call 9876543210.")
                status.text = "Try: Open YouTube / WhatsApp, flashlight on, volume up."
            }
        }
        layout.addView(status); layout.addView(listen); layout.addView(torch); layout.addView(help)
        setContentView(layout)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                arrayOf(Manifest.permission.RECORD_AUDIO), requestAudioPermission)
        }
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            tts.language = Locale("en", "IN")
            tts.setSpeechRate(0.88f)
            say("Hello. I am Jarvis. How can I help you?")
        }
    }

    private fun say(message: String) {
        if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                arrayOf(Manifest.permission.RECORD_AUDIO), requestAudioPermission)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to Jarvis")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try { startActivityForResult(intent, requestSpeech) }
        catch (_: Exception) { say("Speech recognition is not available on this phone.") }
    }

    @Deprecated("Deprecated by Android; kept for broad compatibility with this starter")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestSpeech && resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val command = words?.firstOrNull()?.lowercase(Locale.ROOT).orEmpty()
            status.text = "You said: $command"
            handleCommand(command)
        }
    }

    private fun handleCommand(command: String) {
        when {
            command.contains("flashlight on") || command.contains("torch on") ||
                command.contains("टॉर्च चालू") || command.contains("फ्लैशलाइट चालू") -> {
                setTorch(true); say("Flashlight on.")
            }
            command.contains("flashlight off") || command.contains("torch off") ||
                command.contains("टॉर्च बंद") || command.contains("फ्लैशलाइट बंद") -> {
                setTorch(false); say("Flashlight off.")
            }
            command.contains("volume up") || command.contains("आवाज़ बढ़") -> {
                val a = getSystemService(AUDIO_SERVICE) as AudioManager
                a.adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                say("Volume increased.")
            }
            command.contains("volume down") || command.contains("आवाज़ कम") -> {
                val a = getSystemService(AUDIO_SERVICE) as AudioManager
                a.adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                say("Volume decreased.")
            }
            command.contains("youtube") || command.contains("यूट्यूब") -> openApp("com.google.android.youtube", "YouTube")
            command.contains("whatsapp") || command.contains("व्हाट्सएप") -> openApp("com.whatsapp", "WhatsApp")
            command.contains("settings") || command.contains("सेटिंग") -> {
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)); say("Opening settings.")
            }
            command.startsWith("call ") || command.startsWith("कॉल ") -> {
                val number = command.replace(Regex("[^0-9+]"), "")
                if (number.isNotBlank()) {
                    val i = Intent(Intent.ACTION_DIAL).apply { data = android.net.Uri.parse("tel:$number") }
                    startActivity(i); say("Opening dialer. Please confirm the call.")
                } else say("Please say the phone number.")
            }
            else -> say("Sorry, I did not understand. Please try another command.")
        }
    }

    private fun openApp(packageName: String, label: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            startActivity(launch); say("Opening $label.")
        } else say("$label is not installed.")
    }

    private fun toggleTorch() { setTorch(!torchOn) }

    private fun setTorch(enabled: Boolean) {
        try {
            val camera = getSystemService(CAMERA_SERVICE) as CameraManager
            val id = camera.cameraIdList.firstOrNull { camera.getCameraCharacteristics(it)
                .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (id == null) { say("Flashlight not available."); return }
            camera.setTorchMode(id, enabled)
            torchOn = enabled
        } catch (_: Exception) { say("I cannot control the flashlight right now.") }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
