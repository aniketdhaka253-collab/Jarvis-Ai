JARVIS Android Starter - Realme C67 5G / Android 15

यह शुरुआती source project है, तैयार APK नहीं।

बनाने के लिए:
1. PC/Laptop पर Android Studio (stable) install करें।
2. इस ZIP को extract करें।
3. Android Studio में extracted JARVIS_Android_Starter folder खोलें।
4. Gradle sync पूरा होने दें।
5. Realme फोन में Developer options और USB debugging चालू करके USB से जोड़ें।
6. Android Studio में Run दबाएँ।

पहली बार माइक्रोफोन permission दें। इंटरनेट/Google speech recognition सेवा उपलब्ध होना जरूरी हो सकता है।

टेस्ट कमांड:
- Open YouTube
- Open WhatsApp
- Flashlight on / flashlight off
- Volume up / volume down
- Call 98xxxxxxxx (डायलर खुलेगा; कॉल आपको खुद confirm करनी होगी)

सीमाएँ:
- यह starter हर समय "Hey Jarvis" नहीं सुनता।
- यह केवल कुछ predefined commands समझता है; ChatGPT-जैसा AI brain अभी जोड़ा नहीं गया है।
- Deep Male voice डिवाइस के installed Text-to-Speech voices पर निर्भर है। Settings > Accessibility / Text-to-speech output में voice बदल सकते हैं।
- Android सुरक्षा के कारण फोन लॉक रहते हुए सभी काम या बिना confirmation के कॉल/मैसेज संभव नहीं हैं।
- WhatsApp message भेजना अभी शामिल नहीं है; अगली iteration में सुरक्षित share/intent flow जोड़ा जा सकता है।
